import numpy as np
import random
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import time

class JMPaillier:
    def __init__(self, sk_p, sk_q):
        self.h=1024
        self.w=1024
        self.sk_p = sk_p
        self.sk_q = sk_q
        self.n = self.sk_p * self.sk_q
        self.g = self.n + 1
        self.lambda_n = 0
        self.r = 23
        self.r_n = (self.r ** self.n) % (self.n**2)  #r^n mod n^2
        self.lambda_n = self.LCM((self.sk_p - 1), (self.sk_q - 1))
        self.h_p = self.InverseModular(self.L_function(self.MODEXP(self.g,(sk_p-1),(sk_p**2)),sk_p), sk_p)
        self.h_q = self.InverseModular(self.L_function(self.MODEXP(self.g,(sk_q-1),(sk_q**2)),sk_q), sk_q)

        # CRT Pre computating
        self.M2_Inverse_n2 =self.InverseModular(sk_p, sk_q)
        self.M2_Inverse_n2xp = (self.M2_Inverse_n2 * sk_p) % self.n

        #init image matrix
        self.En_img = np.zeros((self.w, self.h, 3), dtype="int64")
        self.np_img = np.zeros((self.w, self.h, 3), dtype="int64")
        self.De_img = np.zeros((self.w, self.h, 3), dtype="uint8")
        self.random_r = np.zeros((self.w, self.h, 3), dtype="int64")
        self.Paillier_r = np.zeros((self.w, self.h, 3), dtype="int64")
        self.r_random_matrix = (np.random.rand(self.w, self.h, 3) * self.lambda_n)
        self.r_random_matrix = np.array(self.r_random_matrix, dtype="int64")
        self.Generator_random_r_matrix()


    def MODEXP(self, a, n, m):
        a = a % m
        r = 1
        while(n!=0):
            if((n & 1) == 1):
                r = (a * r) % m
            a = a * a  % m
            n = n >> 1
        return r

    def LCM(self, x, y):
        if(x > y):
            greater = x
        elif(x < y):
            greater = y
        while(True):
           if((greater % x == 0) and (greater % y == 0)):
               lcm = greater
               break
           greater += 1
        return lcm

    def exgcd(self, a, b, c ,t1, t2):   #a=14, b=3, t1=0 , t2=1
        # print('----------------------exgcd-------------------------------')
        # b = b % a
        if(b == 0):
            return (t1 + c) % c
        q = int(a / b)
        r = a % b
        t = t1 - t2 * q
        # print(f'a / b:{q}')
        # print(f'a % b:{r}')
        # print(f't1 - t2 * q:{t}')
        t1 = t2
        t2 = t
        a = b
        b = r
        # print('----------------------exgcd--end--------------------------')
        return self.exgcd(a, b, c, t1, t2)


    def InverseModular(self, k, n):  #k=51,n=77

        r = self.exgcd(n, k, n ,0, 1)
        return r

    def L_function(self, x, n):
        L = (x-1)/n
        return L

    def Generator_random_r_matrix(self):
        for k in range(3):
            for j in range(self.h):
                for i in range(self.w):
                    self.random_r[i,j,k] = self.MODEXP(self.r, self.r_random_matrix[i, j, k], self.n)
                    self.Paillier_r[i,j,k] = self.MODEXP(self.random_r[i, j, k], self.n, self.n**2)
    def CRT(self, m1,m2,p,q, pre_m2):   # a^b mod n=> a^b mod (pq)
        M = p * q
        # M1 = q
        # M2 = p
        # M2_inverse = InverseModular(M2, q)
        # print(f'M2_inverse:{M2_inverse}')
        # r = (m1 + (m2-m1)* M2_inverse * p) % M
        r = (m1 + (m2-m1)* pre_m2) % M
        return r
    def CRT_DecryptoPaillier(self, h_p, h_q, c, p, q, M2_Inverse_n2xp):   # a^b mod n=> a^b mod (pq)

        m_p = self.L_function(self.MODEXP(c, (p-1), (p**2)),p) * h_p % p
        m_q = self.L_function(self.MODEXP(c, (q-1), (q**2)),q) * h_q % q
        r = self.CRT(m_p, m_q, p, q, M2_Inverse_n2xp)
        return r
    def EncryptPaillierImg(self, frame):
        # file_bytes = np.asarray(bytearray(frame), dtype=np.uint8)
        # img = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
        frame_resize = cv2.resize(src= frame, dsize=(self.w, self.h))
        img = np.array(frame_resize, dtype='uint64')
        EN_img = (1 + self.n * img) % (self.n**2) #dim is (h, w, 3)
        result = (EN_img * self.Paillier_r) % (self.n**2)
        result = np.array(result, dtype="uint64")
        result_256 = result % 256
        return result, result_256
    def DecryptPaillierImg(self, frame):

        De_img = self.CRT_DecryptoPaillier(self.h_p, self.h_q, frame, self.sk_p, self.sk_q, self.M2_Inverse_n2xp)
        De_img = np.array(De_img, dtype="uint8")
        return De_img

# if __name__ == "__main__":
    # original_img = Image.open("C:\\Image\\building.jpg")
    # original_img = original_img.resize([300,300])
    # original_img_np = np.asarray(original_img)
    # original_img_np = original_img_np.reshape(300, 300, 3)
    #
    #
    # Paillier = JMPaillier(197, 199)  #初始化密鑰
    # result, result_256 = Paillier.EncryptPaillierImg(original_img_np)
    # origin_img = Paillier.DecryptPaillierImg(result)
    #
    # Paillier2 = JMPaillier(151, 157)  #初始化密鑰
    # result2, result_256_2 = Paillier2.EncryptPaillierImg(original_img_np)
    # origin_img_2 = Paillier2.DecryptPaillierImg(result2)
    #
    # # print(origin_img)
    # plt.subplot(2, 3, 1)
    # plt.imshow(original_img_np)
    # plt.title("Original")
    #
    # plt.subplot(2, 3, 2)
    # plt.imshow(result_256)
    # plt.title("ciphertext")
    #
    # plt.subplot(2, 3, 3)
    # plt.imshow(origin_img)
    # plt.title("Decrypt image")
    #
    # plt.subplot(2, 3, 4)
    # plt.imshow(original_img_np)
    # plt.title("Original")
    #
    # plt.subplot(2, 3, 5)
    # plt.imshow(result_256_2)
    # plt.title("ciphertext")
    #
    # plt.subplot(2, 3, 6)
    # plt.imshow(origin_img_2)
    # plt.title("Decrypt image")
    #
    # plt.show()
