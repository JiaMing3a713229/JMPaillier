import JMPaillier as jm
import numpy as np
import random
import cv2
from PIL import Image
import matplotlib.pyplot as plt
import time
import math

def RGB_correlation(channel,N):
  #计算channel通道
  h,w=channel.shape
  #随机产生pixels个[0,w-1)范围内的整数序列
  row=np.random.randint(0,h-1,N)
  col=np.random.randint(0,w-1,N)
  #绘制相邻像素相关性图,统计x,y坐标
  x=[]
  h_y=[]
  v_y=[]
  d_y=[]
  for i in range(N):
    #选择当前一个像素
    x.append(channel[row[i]][col[i]])
    #水平相邻像素是它的右侧也就是同行下一列的像素
    h_y.append(channel[row[i]][col[i]+1])
    #垂直相邻像素是它的下方也就是同列下一行的像素
    v_y.append(channel[row[i]+1][col[i]])
    #对角线相邻像素是它的右下即下一行下一列的那个像素
    d_y.append(channel[row[i]+1][col[i]+1])
  #三个方向的合到一起
  x=x*3
  y=h_y+v_y+d_y

  #结果展示
  # plt.rcParams['font.sans-serif'] = ['SimHei']  # 中文乱码
  # plt.scatter(x,y)
  # plt.show()

  #计算E(x)，计算三个方向相关性时，x没有重新选择也可以更改
  ex=0
  for i in range(N):
    ex+=channel[row[i]][col[i]]
  ex=ex/N
  #计算D(x)
  dx=0
  for i in range(N):
    dx+=(channel[row[i]][col[i]]-ex)**2
  dx/=N

  #水平相邻像素h_y
  #计算E(y)
  h_ey=0
  for i in range(N):
    h_ey+=channel[row[i]][col[i]+1]
  h_ey/=N
  #计算D(y)
  h_dy=0
  for i in range(N):
    h_dy+=(channel[row[i]][col[i]+1]-h_ey)**2
  h_dy/=N
  #计算协方差
  h_cov=0
  for i in range(N):
    h_cov+=(channel[row[i]][col[i]]-ex)*(channel[row[i]][col[i]+1]-h_ey)
  h_cov/=N
  h_Rxy=h_cov/(np.sqrt(dx)*np.sqrt(h_dy))

  #垂直相邻像素v_y
  #计算E(y)
  v_ey=0
  for i in range(N):
    v_ey+=channel[row[i]+1][col[i]]
  v_ey/=N
  #计算D(y)
  v_dy=0
  for i in range(N):
    v_dy+=(channel[row[i]+1][col[i]]-v_ey)**2
  v_dy/=N
  #计算协方差
  v_cov=0
  for i in range(N):
    v_cov+=(channel[row[i]][col[i]]-ex)*(channel[row[i]+1][col[i]]-v_ey)
  v_cov/=N
  v_Rxy=v_cov/(np.sqrt(dx)*np.sqrt(v_dy))

  #对角线相邻像素d_y
  #计算E(y)
  d_ey=0
  for i in range(N):
    d_ey+=channel[row[i]+1][col[i]+1]
  d_ey/=N
  #计算D(y)
  d_dy=0
  for i in range(N):
    d_dy+=(channel[row[i]+1][col[i]+1]-d_ey)**2
  d_dy/=N
  #计算协方差
  d_cov=0
  for i in range(N):
    d_cov+=(channel[row[i]][col[i]]-ex)*(channel[row[i]+1][col[i]+1]-d_ey)
  d_cov/=N
  d_Rxy=d_cov/(np.sqrt(dx)*np.sqrt(d_dy))

  return h_Rxy,v_Rxy,d_Rxy,x,y

def correlation(img,N=3000):
    h,w,_=img.shape
    B,G,R=cv2.split(img)
    R_Rxy=RGB_correlation(R,N)
    G_Rxy=RGB_correlation(G,N)
    B_Rxy=RGB_correlation(B,N)

    print("******该图像的各通道各方向的相关系数为*****")
    print('通道\tHorizontal\tVertical\tDiagonal')
    print(' R    \t{:.4f}    {:.4f}    {:.4f}'.format(R_Rxy[0],R_Rxy[1],R_Rxy[2]))
    print(' G    \t{:.4f}    {:.4f}    {:.4f}'.format(G_Rxy[0],G_Rxy[1],G_Rxy[2]))
    print(' B    \t{:.4f}    {:.4f}    {:.4f}'.format(B_Rxy[0],B_Rxy[1],B_Rxy[2]))
    #结果展示
    plt.subplot(221)
    plt.imshow(img)
    plt.title('origin image')
    #子图2
    plt.subplot(222)
    plt.scatter(R_Rxy[3],R_Rxy[4],s=1,c='red')
    plt.title('R channel')

    #子图3
    plt.subplot(223)
    plt.scatter(G_Rxy[3],G_Rxy[4],s=1,c='green')
    plt.title('G channel')
    #子图4
    plt.subplot(224)
    plt.scatter(B_Rxy[3],B_Rxy[4],s=1,c='blue')
    plt.title('B channel')
    plt.show()

    return R_Rxy[0:3],G_Rxy[0:3],B_Rxy[0:3]

def entropy(img):
    # img=cv2.imread(img)
    w,h,_=img.shape
    B,G,R=cv2.split(img)
    gray1,num1=np.unique(R,return_counts=True)
    gray2,num2=np.unique(G,return_counts=True)
    gray3,num3=np.unique(B,return_counts=True)
    R_entropy=0
    G_entropy=0
    B_entropy=0

    for i in range(len(gray1)):
        p1=num1[i]/(w*h)
        R_entropy-=p1*(math.log(p1,2))
    for i in range(len(gray2)):
        p2=num2[i]/(w*h)
        G_entropy-=p2*(math.log(p2,2))
    for i in range(len(gray3)):
        p3=num3[i]/(w*h)
        B_entropy-=p3*(math.log(p3,2))

    return R_entropy,G_entropy,B_entropy

if __name__ == "__main__":

    original_img = Image.open("C:\\Image\\building.jpg")
    original_img = original_img.resize([1024,1024])
    original_img_np = np.asarray(original_img)
    original_img_np = original_img_np.reshape(1024, 1024, 3)

    pre_time = time.time()
    Paillier = jm.JMPaillier(17, 19)
    result, result_256 = Paillier.EncryptPaillierImg(original_img_np)
    print(f'計算花費{time.time()-pre_time}毫秒')
    origin_img = Paillier.DecryptPaillierImg(result)
    #
    Paillier2 = jm.JMPaillier(167, 173)  #初始化密鑰
    result2, result_256_2 = Paillier2.EncryptPaillierImg(original_img_np)
    origin_img_2 = Paillier2.DecryptPaillierImg(result2)
    #
    print(origin_img)
    plt.subplot(2, 3, 1)
    plt.imshow(original_img_np)
    plt.title("Original")

    plt.subplot(2, 3, 2)
    plt.imshow(result_256)
    plt.title("ciphertext")

    plt.subplot(2, 3, 3)
    plt.imshow(origin_img)
    plt.title("Decrypt image")

    plt.subplot(2, 3, 4)
    plt.imshow(original_img_np)
    plt.title("Original")

    plt.subplot(2, 3, 5)
    plt.imshow(result_256_2)
    plt.title("ciphertext")

    plt.subplot(2, 3, 6)
    plt.imshow(origin_img_2)
    plt.title("Decrypt image")

    plt.show()

    img1 =  result_256
    img2 =  result_256_2
    w,h,_=img2.shape
    # B1,G1,R1=cv2.split(img1)
    # B2,G2,R2=cv2.split(img2)
    # ar,num=np.unique((R1!=R2),return_counts=True)
    # R_npcr=(num[0] if ar[0]==True else num[1])/(w*h)
    # ar,num=np.unique((G1!=G2),return_counts=True)
    # G_npcr=(num[0] if ar[0]==True else num[1])/(w*h)
    # ar,num=np.unique((B1!=B2),return_counts=True)
    # B_npcr=(num[0] if ar[0]==True else num[1])/(w*h)
    #
    # print(f'R_npcr:{R_npcr}')
    # print(f'G_npcr:{G_npcr}')
    # print(f'B_npcr:{B_npcr}')

    B1,G1,R1=cv2.split(img1)
    B2,G2,R2=cv2.split(img2)
    #强制转换元素类型，为了运算
    R1=R1.astype(np.int64)
    R2=R2.astype(np.int64)
    G1=G1.astype(np.int64)
    G2=G2.astype(np.int64)
    B1=B1.astype(np.int64)
    B2=B2.astype(np.int64)

    sumR=np.sum(abs(R1-R2))
    sumG=np.sum(abs(G1-G2))
    sumB=np.sum(abs(B1-B2))
    R_uaci=sumR/255/(w*h)
    G_uaci=sumG/255/(w*h)
    B_uaci=sumB/255/(w*h)

    print(f'R_uaci:{R_uaci}')
    print(f'G_uaci:{G_uaci}')
    print(f'B_uaci:{B_uaci}')
    #
    #
    # # 直方圖分析
    # B,G,R=cv2.split(origin_img)
    # R=R.flatten(order='C')
    # G=G.flatten(order='C')
    # B=B.flatten(order='C')
    #
    # R1=R1.flatten(order='C')
    # G1=G1.flatten(order='C')
    # B1=B1.flatten(order='C')

    # plt.hist(origin_img.flatten(order='C'), bins=256, range=[0, 255], color='gray')
    # plt.title('RGB Channel')
    # plt.xlabel('Pixel Value')
    # plt.ylabel('Frequency')


    # plt.subplot(1, 3, 1)
    # plt.hist(R, bins=256, range=[0, 255], color='red')
    # plt.title('R Channel')
    # plt.xlabel('Pixel Value')
    # plt.ylabel('Frequency')
    # plt.subplot(1, 3, 2)
    # plt.hist(G, bins=256, range=[0, 255], color='green')
    # plt.title('G Channel')
    # plt.xlabel('Pixel Value')
    # plt.ylabel('Frequency')
    #
    # plt.subplot(1, 3, 3)
    # plt.hist(B, bins=256, range=[0, 255], color='blue')
    # plt.title('B Channel')
    # plt.xlabel('Pixel Value')
    # plt.ylabel('Frequency')
    # plt.show()

    # 像素相鄰相關性分析

    # R_Rxy,G_Rxy,B_Rxy=correlation(origin_img)

    #信息墒分析
    # R_entropy,G_entropy,B_entropy=entropy(result_256_2)
    # print('***********信息熵*********')
    # print('通道R:{:.4}'.format(R_entropy))
    # print('通道G:{:.4}'.format(G_entropy))
    # print('通道B:{:.4}'.format(B_entropy))


